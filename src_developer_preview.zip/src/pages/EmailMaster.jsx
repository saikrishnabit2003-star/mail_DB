import { useState, useRef, useMemo, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../context/AuthContext'
import { emailMasterService } from '../services/emailMaster.service'
import Badge from '../components/ui/Badge'
import Table from '../components/ui/Table'
import Button from '../components/ui/Button'
import Modal from '../components/ui/Modal'
import Input from '../components/ui/Input'
import Select from '../components/ui/Select'
import SearchableSelect from '../components/ui/SearchableSelect'
import MultiSelect from '../components/ui/MultiSelect'
import DateRangePicker from '../components/ui/DateRangePicker'
import { Upload, RefreshCw, Trash2, Users, ChevronLeft, ChevronRight, Search, Download, ChevronUp, ChevronDown, Calendar, Pencil } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import * as XLSX from 'xlsx'
import { motion, useReducedMotion } from 'framer-motion'
import { dashboardService } from '../services/dashboard.service'
import ProfileReplies from './ProfileReplies'
import { useDebounce } from '../hooks/useDebounce'

export default function EmailMaster() {
  const { user, isAdmin } = useAuth()
  const qc = useQueryClient()
  const reduce = useReducedMotion()
  const fileRef = useRef()
  const [maxLimit, setMaxLimit] = useState('')
  const [mailSourceUpload, setMailSourceUpload] = useState('')   // selected during upload
  const [search, setSearch] = useState('')
  const debouncedSearch = useDebounce(search, 500)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(50)
  const [countryFilter, setCountryFilter] = useState([])
  const [stateFilter, setStateFilter] = useState([])
  const [domainFilter, setDomainFilter] = useState([])
  const [industryFilter, setIndustryFilter] = useState([])
  const [universityFilter, setuniversityFilter] = useState([])
  const [uploaderFilter, setUploaderFilter] = useState([])
  const [mailSourceFilter, setMailSourceFilter] = useState([])
  const [includeDuplicates, setIncludeDuplicates] = useState(true)
  const [activeTab, setActiveTab] = useState(isAdmin(user) ? 'table' : 'upload') // default tab based on role

  // ---- 3D animation helpers (visual only) ----
  // each tab's content flips in when it opens
  const flip = reduce
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, transition: { duration: 0.2 } }
    : {
        initial: { opacity: 0, rotateX: -12, y: 20 },
        animate: { opacity: 1, rotateX: 0, y: 0 },
        transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
        style: { transformPerspective: 1000, transformOrigin: 'top center' },
      }
  // summary cards lift and tilt toward you
  const hoverCard = reduce
    ? {}
    : { whileHover: { y: -6, rotateX: 4 }, transition: { type: 'spring', stiffness: 300, damping: 20 }, style: { transformPerspective: 900 } }
  // icon tiles float gently
  const floatIcon = reduce
    ? {}
    : { animate: { y: [0, -4, 0] }, transition: { duration: 3, repeat: Infinity, ease: 'easeInOut' } }
  const tabHover = reduce ? undefined : { y: -2, rotateX: 8 }

  // History Tab States
  const [historyPreset, setHistoryPreset] = useState('last_7_days')
  const [historyStartDate, setHistoryStartDate] = useState('')
  const [historyEndDate, setHistoryEndDate] = useState('')
  const [historyEmployee, setHistoryEmployee] = useState('')
  const [historyPage, setHistoryPage] = useState(1)
  const [historyPageSize, setHistoryPageSize] = useState(20)
  const [historySortField, setHistorySortField] = useState(null)
  const [historySortOrder, setHistorySortOrder] = useState('desc')
  // Upload Wizard States
  const [uploadStep, setUploadStep] = useState(1)
  const [workbook, setWorkbook] = useState(null)
  const [selectedSheet, setSelectedSheet] = useState('')
  const [fileHeaders, setFileHeaders] = useState([])
  const [columnMapping, setColumnMapping] = useState({})
  const [uploadSummary, setUploadSummary] = useState(null)
  const [uploadedFile, setUploadedFile] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [editTarget, setEditTarget] = useState(null)
  const [editForm, setEditForm] = useState(null)
  const [deleteSelectedTarget, setDeleteSelectedTarget] = useState(false)
  const [deleteStartDate, setDeleteStartDate] = useState('')
  const [deleteEndDate, setDeleteEndDate] = useState('')
  const [deleteDateRangeModal, setDeleteDateRangeModal] = useState(false)
  const [showDatePicker, setShowDatePicker] = useState(false)
  const datePickerRef = useRef(null)
  const datePickerTriggerRef = useRef(null)
  const datePickerPopupRef = useRef(null)
  const [datePickerPosition, setDatePickerPosition] = useState(null)

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        datePickerRef.current
        && !datePickerRef.current.contains(event.target)
        && !datePickerPopupRef.current?.contains(event.target)
      ) {
        setShowDatePicker(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    if (!showDatePicker) return

    const updateDatePickerPosition = () => {
      const trigger = datePickerTriggerRef.current
      if (!trigger) return

      const rect = trigger.getBoundingClientRect()
      const popupWidth = 280
      const popupHeight = 360
      const top = rect.bottom + 8
      setDatePickerPosition({
        left: Math.max(8, Math.min(rect.left, window.innerWidth - popupWidth - 8)),
        top: Math.max(8, Math.min(top, window.innerHeight - popupHeight - 8)),
      })
    }

    updateDatePickerPosition()
    window.addEventListener('resize', updateDatePickerPosition)
    window.addEventListener('scroll', updateDatePickerPosition, true)
    return () => {
      window.removeEventListener('resize', updateDatePickerPosition)
      window.removeEventListener('scroll', updateDatePickerPosition, true)
    }
  }, [showDatePicker])

  const [selectedRows, setSelectedRows] = useState([])
  const [exportModal, setExportModal] = useState(false)
  const [exportFormat, setExportFormat] = useState('xlsx')

  const STANDARD_FIELDS = ['Email', 'Full Name', 'University', 'Country', 'State', 'City', 'Industry', 'Designation', 'Domain', 'Domain Group', 'Phone', 'Website', 'LinkedIn', 'Citation']

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['email-master', page, pageSize, debouncedSearch, countryFilter, stateFilter, domainFilter, industryFilter, universityFilter, uploaderFilter, mailSourceFilter, includeDuplicates],
    queryFn: () => emailMasterService.list({
      page,
      pageSize,
      search: debouncedSearch || undefined,
      searchFields: debouncedSearch ? 'email,fullName,university,domain,domain_group' : undefined,
      country: countryFilter.length ? countryFilter.join(',') : undefined,
      state: stateFilter.length ? stateFilter.join(',') : undefined,
      domain: domainFilter.length ? domainFilter.join(',') : undefined,
      industry: industryFilter.length ? industryFilter.join(',') : undefined,
      university: universityFilter.length ? universityFilter.join(',') : undefined,
      uploadedBy: uploaderFilter.length ? uploaderFilter.join(',') : undefined,
      mailSource: mailSourceFilter.length ? mailSourceFilter.join(',') : undefined,
      includeDuplicates,
    }),
    placeholderData: (prev) => prev,
    staleTime: 5 * 60 * 1000, // 5 minutes
  })

  const rawData = data?.data?.data
  const records = rawData?.data ?? (Array.isArray(rawData) ? rawData : [])
  const total = rawData?.total ?? 0
  const totalPages = rawData?.totalPages ?? 1
  const { data: optionsRes } = useQuery({
    queryKey: ['email-master-options'],
    queryFn: () => emailMasterService.getDropdownOptions(),
    staleTime: 1000 * 60 * 30,
  })
  const options = optionsRes?.data?.data || {}

  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ['email-master-stats'],
    queryFn: () => emailMasterService.getUploaderStats(),
    enabled: total > 0 && isAdmin(user),
    retry: 0,
  })

  const { data: historyData, isLoading: historyLoading } = useQuery({
    queryKey: ['upload-history', historyPreset, historyEmployee, historyStartDate, historyEndDate, historyPage, historyPageSize],
    queryFn: () => dashboardService.uploadHistory({
      preset: historyPreset,
      employeeId: historyEmployee || undefined,
      startDate: historyPreset === 'custom' ? historyStartDate : undefined,
      endDate: historyPreset === 'custom' ? historyEndDate : undefined,
      page: historyPage,
      page_size: historyPageSize
    }),
    enabled: activeTab === 'history' && isAdmin(user),
    retry: 0,
  })

  const { data: replyStatsData, isLoading: replyStatsLoading } = useQuery({
    queryKey: ['email-master-reply-stats'],
    queryFn: () => emailMasterService.getReplyStats(),
    enabled: activeTab === 'reply-stats' && isAdmin(user),
    retry: 0,
  })
  const replyStats = replyStatsData?.data?.data || null

  const responseData = historyData?.data || {}
  const rawLogs = responseData.records || responseData.data?.records || []
  console.log("UPLOAD HISTORY RESPONSE:", responseData)
  let historyLogs = Array.isArray(rawLogs) ? [...rawLogs] : []

  if (historySortField) {
    historyLogs.sort((a, b) => {
      let valA = a[historySortField] || 0
      let valB = b[historySortField] || 0
      if (historySortOrder === 'asc') return valA - valB
      return valB - valA
    })
  }
  const historyPagination = responseData.pagination || responseData.data?.pagination || { page: 1, total: 0, total_pages: 1 }
  const historyTotal = historyPagination.total || 0
  const historyTotalPages = historyPagination.total_pages || 1
  const historySummary = responseData.totals || responseData.data?.totals || {
    totalUploads: 0,
    totalUnique: 0,
    totalDuplicate: 0,
    totalInvalid: 0
  }

  const uploaders = options.uploaders || []
  const countries = options.countries || []
  const states = options.states || []
  const domains = options.domains || []
  const industries = options.industries || []
  const companies = options.companies || []
  const mailSources = options.mailSources || []

  const getErrorMessage = (e, fallback = 'Failed') => {
    const data = e.response?.data;
    if (data?.message === 'Validation error' && Array.isArray(data?.data) && data.data.length > 0) {
      return data.data[0].msg || data.message;
    }
    return data?.message || fallback;
  }

  const uploadMut = useMutation({
    mutationFn: ({ file, max, source }) => emailMasterService.upload(file, max || undefined, source || undefined),
    onSuccess: (r) => {
      qc.invalidateQueries(['email-master'])
      qc.invalidateQueries(['email-master-options'])
      setUploadSummary(r.data)
      setUploadStep(3)
      toast.success(r.data?.message || 'Upload successful')
      if (fileRef.current) fileRef.current.value = ''


    },
    onError: (e) => {
      toast.error(getErrorMessage(e, 'Upload failed'))
    },
    onSettled: () => {
      setIsProcessing(false)
    }
  })

  const deleteMut = useMutation({
    mutationFn: (id) => emailMasterService.deleteEmail(id),
    onSuccess: () => {
      qc.invalidateQueries(['email-master'])
      toast.success('Email deleted')
    },
    onError: (e) => toast.error(getErrorMessage(e, 'Delete failed')),
  })

  const updateEmailMut = useMutation({
    mutationFn: ({ id, data }) => emailMasterService.updateEmail(id, data),
    onSuccess: (response) => {
      qc.invalidateQueries(['email-master'])
      setEditTarget(null)
      setEditForm(null)
      toast.success(response.data.message)
    },
    onError: (e) => toast.error(getErrorMessage(e, 'Failed to update email details')),
  })

  const deleteSelectedMut = useMutation({
    mutationFn: (ids) => Promise.all(ids.map(id => emailMasterService.deleteEmail(id))),
    onSuccess: () => {
      qc.invalidateQueries(['email-master'])
      setSelectedRows([])
      toast.success('Selected emails deleted')
    },
    onError: (e) => toast.error(getErrorMessage(e, 'Failed to delete selected emails or Dont have permission to delete it ')),
  })

  const deleteByDateRangeMut = useMutation({
    mutationFn: () => {
      const formatToDDMMYYYY = (dateStr) => {
        if (!dateStr) return '';
        const [y, m, d] = dateStr.split('-');
        return `${d}-${m}-${y}`;
      }
      return emailMasterService.deleteByDateRange(formatToDDMMYYYY(deleteStartDate), formatToDDMMYYYY(deleteEndDate))
    },
    onSuccess: () => {
      qc.invalidateQueries(['email-master'])
      toast.success('Emails deleted successfully')
      setDeleteDateRangeModal(false)
      setDeleteStartDate('')
      setDeleteEndDate('')
    },
    onError: (e) => toast.error(getErrorMessage(e, 'Failed to delete by date range')),
  })

  const exportMut = useMutation({
    mutationFn: (format) => emailMasterService.download({
      format,
      search: debouncedSearch || undefined,
      country: countryFilter.length ? countryFilter.join(',') : undefined,
      state: stateFilter.length ? stateFilter.join(',') : undefined,
      domain: domainFilter.length ? domainFilter.join(',') : undefined,
      industry: industryFilter.length ? industryFilter.join(',') : undefined,
      university: universityFilter.length ? universityFilter.join(',') : undefined,
      mailSource: mailSourceFilter.length ? mailSourceFilter.join(',') : undefined,
      includeDuplicates,
    }),
    onSuccess: (res, format) => {
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `email_master.${format}`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      setExportModal(false)
      toast.success('Export completed!')
    },
    onError: (e) => {
      toast.error(getErrorMessage(e, 'Export failed'))
    }
  })


  const handleFile = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (!mailSourceUpload) {
      toast.error('Please select a Mail Source before uploading')
      if (fileRef.current) fileRef.current.value = ''
      return
    }

    try {
      setIsProcessing(true)
      const data = await file.arrayBuffer()
      const wb = XLSX.read(data)
      setWorkbook(wb)
      setUploadedFile(file)

      const sheetName = wb.SheetNames[0]
      setSelectedSheet(sheetName)

      const ws = wb.Sheets[sheetName]
      const headers = XLSX.utils.sheet_to_json(ws, { header: 1 })[0] || []
      setFileHeaders(headers.filter(Boolean).map(String))

      // Auto-map if possible
      const initialMap = {}
      STANDARD_FIELDS.forEach(sf => {
        const match = headers.find(h => String(h).toLowerCase().replace(/[^a-z0-9]/g, '') === sf.toLowerCase().replace(/[^a-z0-9]/g, ''))
        if (match) initialMap[sf] = String(match)
      })
      setColumnMapping(initialMap)
      setUploadStep(2)
    } catch (err) {
      toast.error('Failed to parse file')
      console.error(err)
    } finally {
      setIsProcessing(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const handleProcessAndUpload = () => {
    if (!columnMapping['Email']) {
      toast.error('Email field must be mapped')
      return
    }

    setIsProcessing(true)
    setTimeout(() => {
      try {
        const ws = workbook.Sheets[selectedSheet]
        const rawData = XLSX.utils.sheet_to_json(ws)

        const mappedData = rawData.map(row => {
          const newRow = {}
          STANDARD_FIELDS.forEach(sf => {
            const mappedHeader = columnMapping[sf]
            if (mappedHeader && row[mappedHeader] !== undefined && row[mappedHeader] !== null) {
              newRow[sf] = String(row[mappedHeader]).trim()
            }
          })
          return newRow
        }).filter(row => row['Email']) // Drop rows without email

        if (mappedData.length === 0) {
          toast.error('No valid rows with emails found')
          setIsProcessing(false)
          return
        }

        const newWs = XLSX.utils.json_to_sheet(mappedData, { header: STANDARD_FIELDS })
        const csvString = XLSX.utils.sheet_to_csv(newWs)
        const newFile = new File([csvString], uploadedFile.name.replace(/\.[^/.]+$/, "") + "_mapped.csv", { type: 'text/csv' })

        uploadMut.mutate({ file: newFile, max: maxLimit ? Number(maxLimit) : undefined, source: mailSourceUpload })
      } catch (err) {
        toast.error('Error processing mapped data')
        console.error(err)
        setIsProcessing(false)
      }
    }, 100)
  }

  const handleDownloadSample = () => {
    const sampleData = [{
      'Email': 'sample@example.com',
      'Full Name': 'John Doe',
      'University': 'Sample University',
      'Country': 'USA',
      'State': 'CA',
      'City': 'San Francisco',
      'Industry': 'Technology',
      'Designation': 'Engineer',
      'Domain': 'example.com',
      'Domain Group': 'IT,AIML,IOT/python',
      'Phone': '1234567890',
      'Website': 'https://example.com',
      'LinkedIn': 'https://linkedin.com/in/sample',
      'Citation': ''
    }]
    const ws = XLSX.utils.json_to_sheet(sampleData, { header: STANDARD_FIELDS })
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Sample')
    XLSX.writeFile(wb, 'sample_emails.xlsx')
  }

  const stats = statsData?.data?.stats || []

  const highlightMatch = (text, query) => {
    if (!query || !text) return text;
    const regex = new RegExp(`(${query})`, 'gi');
    const parts = String(text).split(regex);
    return (
      <>
        {parts.map((part, i) =>
          regex.test(part) ? (
            <mark key={i} className="bg-yellow-200 text-gray-900 rounded-sm px-0.5">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  const toggleRowSelect = (id) => {
    setSelectedRows(prev => prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id])
  }

  const toggleAllRows = (e) => {
    if (e.target.checked) {
      setSelectedRows(records.map(r => r.id || r._id))
    } else {
      setSelectedRows([])
    }
  }

  const columns = useMemo(() => [
    // {
    //   key: 'select',
    //   label: <input type="checkbox" onChange={toggleAllRows} checked={records.length > 0 && selectedRows.length === records.length} className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer" />,
    //   sortable: false,
    //   render: (_, row) => (
    //     <input
    //       type="checkbox"
    //       checked={selectedRows.includes(row.id || row._id)}
    //       onChange={() => toggleRowSelect(row.id || row._id)}
    //       className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
    //     />
    //   )
    // },
    {
      key: 'actions', label: 'Action',
      render: (_, row) => (
        <div className="flex items-center gap-1">
          <motion.button
            type="button"
            whileHover={reduce ? undefined : { scale: 1.2, rotateY: 25, rotateX: -10 }}
            style={{ transformPerspective: 300 }}
            onClick={() => {
              setEditTarget(row)
              setEditForm({
                fullName: row.fullName || '',
                email: row.email || '',
                university: row.university || '',
                website: row.website || '',
                country: row.country || '',
                state: row.state || '',
                city: row.city || '',
                domain: Array.isArray(row.domain) ? row.domain.join(', ') : row.domain || '',
                domain_group: Array.isArray(row.domain_group) ? row.domain_group.join(', ') : row.domain_group || '',
                industry: row.industry || '',
                designation: row.designation || '',
                phone: row.phone || '',
                linkedin: row.linkedin || '',
              })
            }}
            aria-label="Edit email details"
            title="Edit"
            className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"
          >
            <Pencil className="w-4 h-4" />
          </motion.button>
          <motion.button
            type="button"
            whileHover={reduce ? undefined : { scale: 1.2, rotateY: 25, rotateX: -10 }}
            style={{ transformPerspective: 300 }}
            onClick={() => setDeleteTarget(row)}
            aria-label="Delete email"
            title="Delete"
            className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
          >
            <Trash2 className="w-4 h-4" />
          </motion.button>
        </div>
      )
    },
    { key: 'sno', label: 'S.No', sortable: false, render: (_, __, i) => i + 1 + (page - 1) * pageSize },
    { key: 'fullName', label: 'Full Name', render: v => v ? highlightMatch(v, search) : '—' },
    { key: 'email', label: 'Email', render: v => <span className="font-medium text-blue-600">{v ? highlightMatch(v, search) : ''}</span> },
    { key: 'university', label: 'University', render: v => v ? highlightMatch(v, search) : '—' },
    {
      key: 'website', label: 'Website',
      render: v => v
        ? <a href={v} target="_blank" rel="noreferrer" className="inline-block px-2.5 py-1 text-xs font-medium bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors border border-blue-100">View</a>
        : '—'
    },
    { key: 'country', label: 'Country', render: v => v ? highlightMatch(v, search) : '—' },
    { key: 'state', label: 'State', render: v => v ? highlightMatch(v, search) : '—' },
    { key: 'city', label: 'City', render: v => v ? highlightMatch(v, search) : '—' },
    // { key: '', label: 'Domain', render: v => v ? highlightMatch(v, search) : '—' },
    {
      key: 'domain', label: 'Domain', minWidth: '300px', render: v => {
        const text = Array.isArray(v) ? v.join(', ') : v;
        return text ? <div className="max-h-24 overflow-y-auto whitespace-pre-wrap pr-1 custom-scrollbar">{highlightMatch(text, search)}</div> : '—';
      }
    },
    {
      key: 'domain_group', label: 'Domain Group', minWidth: '300px', render: v => {
        const text = Array.isArray(v) ? v.join(', ') : v;
        return text ? <div className="max-h-24 overflow-y-auto whitespace-pre-wrap pr-1 custom-scrollbar">{highlightMatch(text, search)}</div> : '—';
      }
    },
    { key: 'industry', label: 'Industry', render: v => v ? highlightMatch(v, search) : '—' },
    { key: 'designation', label: 'Designation', render: v => v ? highlightMatch(v, search) : '—' },
    { key: 'phone', label: 'Phone', render: v => v || '—' },
    {
      key: 'linkedin', label: 'LinkedIn',
      render: v => v
        ? <a href={v.startsWith('http') ? v : `https://${v}`} target="_blank" rel="noreferrer" className="inline-block px-2.5 py-1 text-xs font-medium bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors border border-blue-100">View</a>
        : '—'
    },
    {
      key: 'mailSource', label: 'Mail Source', render: v => v
        ? <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-medium">{v}</span>
        : '—'
    },
    {
      key: 'inProfileEmails', label: 'In Profile',
      render: v => <Badge label={v ? 'Yes' : 'No'} />
    },
    {
      key: 'usageCount', label: 'Usage Count',
      render: v => <span className="text-xs text-gray-600 font-medium">{v || 0}</span>
    },
    {
      key: 'usedByEmployeeNames', label: 'Used By Employees',
      render: v => <span className="text-xs text-gray-600">{(v && v.length > 0) ? v.join(', ') : '—'}</span>
    },
    {
      key: 'uploadedByName', label: 'Uploaded By',
      render: v => <span className="text-xs text-gray-600">{v || '—'}</span>
    },
    {
      key: 'uploadedDate', label: 'Upload Date',
      render: v => v ? format(new Date(v), 'MMM d, yyyy') : '—'
    },
    
  ], [records, selectedRows, page, pageSize, search, reduce])

  const handleHistorySort = (field) => {
    if (historySortField === field) {
      setHistorySortOrder(prev => prev === 'desc' ? 'asc' : 'desc')
    } else {
      setHistorySortField(field)
      setHistorySortOrder('desc')
    }
  }

  const renderHistorySortHeader = (title, field) => (
    <div className="flex items-center gap-1 cursor-pointer" onClick={() => handleHistorySort(field)}>
      <span>{title}</span>
      <div className="flex flex-col text-[8px] opacity-50">
        <ChevronUp className={`w-3 h-3 -mb-1 ${historySortField === field && historySortOrder === 'asc' ? 'text-primary-600 opacity-100' : ''}`} />
        <ChevronDown className={`w-3 h-3 ${historySortField === field && historySortOrder === 'desc' ? 'text-primary-600 opacity-100' : ''}`} />
      </div>
    </div>
  )

  const historyColumns = [
    { key: 'sno', label: 'S.No', render: (_, __, i) => <span className="text-gray-400 font-medium">{i + 1 + (historyPage - 1) * historyPageSize}</span> },
    { key: 'employeeName', label: `User's`, render: v => <span className="font-medium text-gray-900">{v || 'Unknown'}</span> },
    { key: 'employeeEmail', label: 'Email', render: v => <span className="text-gray-500">{v || '—'}</span> },
    { key: 'date', label: 'Date', render: v => { if (!v) return '—'; const d = String(v).split('T')[0]; return <span className="text-gray-500">{format(new Date(d + 'T00:00:00'), 'MMM d, yyyy')}</span> } },
    { key: 'uploadCount', label: renderHistorySortHeader('Total Uploaded', 'uploadCount'), render: v => <span className="font-semibold text-gray-900">{(v || 0).toLocaleString()}</span> },
    { key: 'uniqueCount', label: renderHistorySortHeader('Unique', 'uniqueCount'), render: v => <span className="font-medium text-emerald-600">{(v || 0).toLocaleString()}</span> },
    { key: 'duplicateCount', label: renderHistorySortHeader('Duplicate', 'duplicateCount'), render: v => <span className="font-medium text-amber-500">{(v || 0).toLocaleString()}</span> },
    { key: 'invalidCount', label: renderHistorySortHeader('Invalid', 'invalidCount'), render: v => <span className="font-medium text-red-500">{(v || 0).toLocaleString()}</span> },
  ]
  console.log(uploadedFile, "UploadedFile")
  return (
    <div className="space-y-5 rounded-3xl border border-white/60 bg-gradient-to-br from-sky-50 via-indigo-50/70 to-cyan-50 p-5 shadow-inner">
      {/* Tabs */}
      <div className="flex flex-wrap gap-1 sm:space-x-1 sm:gap-0 bg-gray-100/50 p-1 rounded-xl w-full sm:w-fit border border-gray-200">
        <motion.button
          whileHover={tabHover}
          style={{ transformPerspective: 400 }}
          onClick={() => setActiveTab('upload')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === 'upload'
            ? 'bg-white text-primary-600 shadow-sm'
            : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'
            }`}
        >
          Upload File
        </motion.button>
        
        {isAdmin(user) && (
          <>
            <motion.button
              whileHover={tabHover}
              style={{ transformPerspective: 400 }}
              onClick={() => setActiveTab('table')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === 'table'
                ? 'bg-white text-primary-600 shadow-sm'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'
                }`}
            >
              Show Table
            </motion.button>
            <motion.button
              whileHover={tabHover}
              style={{ transformPerspective: 400 }}
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === 'history'
                ? 'bg-white text-primary-600 shadow-sm'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'
                }`}
            >
              History
            </motion.button>
            <motion.button
              whileHover={tabHover}
              style={{ transformPerspective: 400 }}
              onClick={() => setActiveTab('reply-stats')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === 'reply-stats'
                ? 'bg-white text-primary-600 shadow-sm'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'
                }`}
            >
              Reply Stats
            </motion.button>
          </>
        )}
        <motion.button
          whileHover={tabHover}
          style={{ transformPerspective: 400 }}
          onClick={() => setActiveTab('replies')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === 'replies'
            ? 'bg-white text-primary-600 shadow-sm'
            : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'
            }`}
        >
          Client Replies
        </motion.button>
      </div>

      {activeTab === 'upload' && (
        <motion.div {...flip} className="space-y-5">
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">

            {uploadStep === 1 && (
              <>
                <h3 className="font-semibold text-gray-800 mb-4">Step 1: Upload Emails (Global DB)</h3>
                <div className="flex flex-wrap items-end gap-3">
                  <div className="w-44">
                    <Select
                      label="Mail Source *"
                      value={mailSourceUpload}
                      onChange={e => setMailSourceUpload(e.target.value)}
                    >
                      <option value="">-- Select Source --</option>
                      <option value="Google Scholar">Google Scholar</option>
                      <option value="University">University</option>
                      <option value="Other">Other</option>
                    </Select>
                  </div>

                  <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls" onChange={handleFile} className="hidden" />
                  <div className="flex gap-3">
                    <Button onClick={() => fileRef.current.click()} loading={isProcessing} disabled={!mailSourceUpload}>
                      <Upload className="w-4 h-4" />
                      {isProcessing ? 'Processing...' : 'Select File'}
                    </Button>
                    <Button variant="secondary" onClick={handleDownloadSample}>
                      <Download className="w-4 h-4" />
                      Download Sample
                    </Button>
                  </div>
                </div>
              </>
            )}

            {uploadStep === 2 && (
              <>
                <h3 className="font-semibold text-gray-800 mb-4">Step 2: Map Columns</h3>
                {workbook && workbook.SheetNames.length > 1 && (
                  <div className="mb-4 w-64">
                    <Select label="Select Sheet" value={selectedSheet} onChange={e => {
                      const sn = e.target.value
                      setSelectedSheet(sn)
                      const ws = workbook.Sheets[sn]
                      const headers = XLSX.utils.sheet_to_json(ws, { header: 1 })[0] || []
                      setFileHeaders(headers.filter(Boolean).map(String))
                    }}>
                      {workbook.SheetNames.map(sn => <option key={sn} value={sn}>{sn}</option>)}
                    </Select>
                  </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {STANDARD_FIELDS.map(sf => (
                    <div key={sf} className="flex items-center gap-4 bg-gray-50 p-2 rounded-lg">
                      <span className="w-32 font-medium text-sm text-gray-700">{sf} {sf === 'Email' && <span className="text-red-500">*</span>}</span>
                      <Select
                        value={columnMapping[sf] || ''}
                        onChange={e => setColumnMapping(prev => ({ ...prev, [sf]: e.target.value }))}
                      >
                        <option value="">-- Ignore --</option>
                        {fileHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </Select>
                    </div>
                  ))}
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="secondary" onClick={() => { setUploadStep(1); setUploadedFile(null); setWorkbook(null) }}>Cancel</Button>
                  <Button loading={isProcessing || uploadMut.isPending} onClick={handleProcessAndUpload}>Process & Upload</Button>
                </div>
              </>
            )}

            {uploadStep === 3 && uploadSummary && (
              <>
                <h3 className="font-semibold text-gray-800 mb-4">Step 3: Upload Summary</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <motion.div {...hoverCard} className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                    <p className="text-blue-600 text-sm font-medium">Total Uploaded</p>
                    <p className="text-2xl font-bold text-blue-900">{uploadSummary.data?.totalUploaded || 0}</p>
                  </motion.div>
                  <motion.div {...hoverCard} className="bg-green-50 p-4 rounded-xl border border-green-100">
                    <p className="text-green-600 text-sm font-medium">Unique</p>
                    <p className="text-2xl font-bold text-green-900">{uploadSummary.data?.unique || 0}</p>
                  </motion.div>
                  <motion.div {...hoverCard} className="bg-amber-50 p-4 rounded-xl border border-amber-100">
                    <p className="text-amber-600 text-sm font-medium">Duplicate</p>
                    <p className="text-2xl font-bold text-amber-900">{uploadSummary.data?.duplicate || 0}</p>
                  </motion.div>
                  <motion.div {...hoverCard} className="bg-red-50 p-4 rounded-xl border border-red-100">
                    <p className="text-red-600 text-sm font-medium">Failed</p>
                    <p className="text-2xl font-bold text-red-900">{uploadSummary.data?.failed || 0}</p>
                  </motion.div>
                </div>
                <div className="flex gap-3">
                  <Button onClick={() => { setUploadStep(1); setUploadSummary(null); setUploadedFile(null); setWorkbook(null); setMailSourceUpload(''); }}>Start New Upload</Button>
                  {(uploadSummary?.failedEmails?.length > 0 || uploadSummary?.data?.failedEmails?.length > 0) && (
                    <Button variant="secondary" onClick={() => {
                      try {
                        const emailsToDownload = uploadSummary.failedEmails || uploadSummary.data.failedEmails;
                        const formattedEmails = emailsToDownload.map(email => {
                          const formattedEmail = { ...email };
                          for (const key in formattedEmail) {
                            if (Array.isArray(formattedEmail[key])) {
                              formattedEmail[key] = formattedEmail[key].join(',');
                            }
                          }
                          return formattedEmail;
                        });
                        const ws = XLSX.utils.json_to_sheet(formattedEmails)
                        const wb = XLSX.utils.book_new()
                        console.log("ws :", formattedEmails)
                        XLSX.utils.book_append_sheet(wb, ws, "Failed Emails")
                        XLSX.writeFile(wb, "uploaded_failed_mails_list.xlsx")
                      } catch (err) {
                        console.error("Error generating failed emails excel:", err)
                        toast.error("Failed to generate Excel file")
                      }
                    }}>
                      <Download className="w-4 h-4" /> Download Failed Emails
                    </Button>
                  )}
                </div>
              </>
            )}
          </div>
        </motion.div>
      )}

      {activeTab === 'history' && isAdmin(user) && (
        <motion.div {...flip} className="space-y-6">
          <div className="relative z-30 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Upload className="w-6 h-6 text-indigo-600" />
                Upload History
              </h2>
              <p className="text-gray-500 mt-1">Track email uploads from active employees.</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="w-48">
                <SearchableSelect
                  value={historyEmployee}
                  onChange={val => setHistoryEmployee(val)}
                  options={[
                    { label: 'All Employees', value: '' },
                    ...(responseData.employees || responseData.data?.employees || uploaders).map(u => ({ label: u.name, value: u.id || u._id }))
                  ]}
                  placeholder="All Employees"
                />
              </div>

              <div className="flex bg-gray-100/80 p-1 rounded-xl border border-gray-200/50">
                {['today', 'last_7_days', 'last_month', 'custom'].map(p => (
                  <motion.button
                    key={p}
                    whileHover={tabHover}
                    style={{ transformPerspective: 400 }}
                    onClick={() => setHistoryPreset(p)}
                    className={`px-4 py-1.5 text-xs font-medium rounded-lg transition-colors ${historyPreset === p ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                      }`}
                  >
                    {p === 'today' ? 'Today' : p === 'last_7_days' ? 'Last 7 Days' : p === 'last_month' ? 'Last Month' : 'Custom'}
                  </motion.button>
                ))}
              </div>

              {historyPreset === 'custom' && (
                <div className="flex items-center gap-2">
                  <input
                    type="date"
                    value={historyStartDate}
                    max={historyEndDate || undefined}
                    onChange={e => setHistoryStartDate(e.target.value)}
                    className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                  <span className="text-gray-400 text-sm">to</span>
                  <input
                    type="date"
                    value={historyEndDate}
                    min={historyStartDate || undefined}
                    onChange={e => setHistoryEndDate(e.target.value)}
                    className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4 shadow-sm">
              <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/30">
                <Upload className="w-6 h-6 text-white" />
              </motion.div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Total Uploaded</p>
                <p className="text-2xl font-bold text-gray-900">{historySummary.totalUploads?.toLocaleString() || 0}</p>
              </div>
            </motion.div>
            <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4 shadow-sm">
              <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/30">
                <RefreshCw className="w-6 h-6 text-white" />
              </motion.div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Total Unique</p>
                <p className="text-2xl font-bold text-gray-900">{historySummary.totalUnique?.toLocaleString() || 0}</p>
              </div>
            </motion.div>
            <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4 shadow-sm">
              <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/30">
                <Users className="w-6 h-6 text-white" />
              </motion.div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Total Duplicate</p>
                <p className="text-2xl font-bold text-gray-900">{historySummary.totalDuplicate?.toLocaleString() || 0}</p>
              </div>
            </motion.div>
            <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4 shadow-sm">
              <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-red-500 flex items-center justify-center shrink-0 shadow-lg shadow-red-500/30">
                <Trash2 className="w-6 h-6 text-white" />
              </motion.div>
              <div>
                <p className="text-sm text-gray-500 font-medium">Total Invalid</p>
                <p className="text-2xl font-bold text-gray-900">{historySummary.totalInvalid?.toLocaleString() || 0}</p>
              </div>
            </motion.div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-500" /> Upload Log
              </h3>
            </div>

            <Table
              columns={historyColumns}
              data={historyLogs}
              loading={historyLoading}
              emptyMsg="No upload logs found"
              wrapperClassName="overflow-auto bg-white max-h-[500px]"
            />
            {/* Pagination Footer for History */}
            <div className="p-4 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500 bg-white">
              <div>
                Showing <span className="font-medium text-gray-900">{historyTotal > 0 ? (historyPage - 1) * historyPageSize + 1 : 0}-{Math.min(historyPage * historyPageSize, historyTotal)}</span> of <span className="font-medium text-gray-900">{historyTotal}</span> logs
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span>Show:</span>
                  <select
                    value={historyPageSize}
                    onChange={e => { setHistoryPageSize(Number(e.target.value)); setHistoryPage(1) }}
                    className="border border-gray-200 rounded-md py-1 px-2 bg-white focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setHistoryPage(Math.max(1, historyPage - 1))}
                    disabled={historyPage === 1}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <span>Page {historyPage} of {historyTotalPages}</span>
                  <button
                    onClick={() => setHistoryPage(Math.min(historyTotalPages, historyPage + 1))}
                    disabled={historyPage === historyTotalPages}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === 'replies' && (
        <ProfileReplies />
      )}

      {activeTab === 'reply-stats' && isAdmin(user) && (
        <motion.div {...flip} className="space-y-5">

          {/* Summary Cards */}
          {replyStatsLoading ? (
            <div className="flex items-center justify-center py-12 text-gray-400 text-sm">Loading stats...</div>
          ) : replyStats ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
                  <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
                    <Users className="w-6 h-6 text-blue-500" />
                  </motion.div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Total Replies</p>
                    <p className="text-2xl font-bold text-gray-900">{replyStats.summary?.totalReplies ?? 0}</p>
                  </div>
                </motion.div>
                <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
                  <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
                    <RefreshCw className="w-6 h-6 text-emerald-500" />
                  </motion.div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Converted</p>
                    <p className="text-2xl font-bold text-emerald-600">{replyStats.summary?.convertedCount ?? 0}</p>
                  </div>
                </motion.div>
                <motion.div {...hoverCard} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
                  <motion.div {...floatIcon} className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center shrink-0">
                    <Upload className="w-6 h-6 text-amber-500" />
                  </motion.div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wide">Other</p>
                    <p className="text-2xl font-bold text-amber-600">{replyStats.summary?.otherCount ?? 0}</p>
                  </div>
                </motion.div>
              </div>

              {/* Breakdown Table */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-100">
                  <p className="font-semibold text-gray-800">Handler Breakdown</p>
                  <p className="text-xs text-gray-400 mt-0.5">Reply performance by each handler</p>
                </div>
                <div className="overflow-auto max-h-[420px]">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 z-10">
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">S.No</th>
                        <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Handler</th>
                        <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Handler Mail</th>
                        <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Replies</th>
                        <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Converted</th>
                        <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Other</th>
                        {/* <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Conversion Rate</th> */}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {(replyStats.breakdown || []).map((row, idx) => {
                        const rate = row.totalReplies > 0 ? Math.round((row.converted / row.totalReplies) * 100) : 0
                        return (
                          <tr key={row.handlerId} className="hover:bg-gray-50/50 transition-colors">
                            <td className="px-5 py-4 text-gray-400 font-medium">{idx + 1}</td>
                            <td className="px-5 py-4">
                              <div className="flex items-center gap-2.5">
                                <motion.div
                                  whileHover={reduce ? undefined : { rotateY: 360 }}
                                  transition={{ duration: 0.7, ease: 'easeInOut' }}
                                  style={{ transformPerspective: 300 }}
                                  className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-xs font-bold text-white uppercase shrink-0"
                                >
                                  {row.handlerName?.[0] || 'H'}
                                </motion.div>
                                <span className="font-medium text-gray-900">{row.handlerName}</span>
                              </div>
                            </td>
                            <td className="px-5 py-4">
                              <div className="flex items-center gap-2.5">
                                <span className="font-medium text-gray-900">{row.handlerEmail}</span>
                              </div>
                            </td>
                            <td className="px-5 py-4 text-center">
                              <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-700">{row.totalReplies}</span>
                            </td>
                            <td className="px-5 py-4 text-center">
                              <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                                {row.converted}
                              </span>
                            </td>
                            <td className="px-5 py-4 text-center">
                              <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                                {row.other}
                              </span>
                            </td>
                            {/* <td className="px-5 py-4 text-center">
                              <div className="flex items-center justify-center gap-2">
                                <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-emerald-500 rounded-full transition-all"
                                    style={{ width: `${rate}%` }}
                                  />
                                </div>
                                <span className="text-xs font-semibold text-gray-600">{rate}%</span>
                              </div>
                            </td> */}
                          </tr>
                        )
                      })}
                      {(!replyStats.breakdown || replyStats.breakdown.length === 0) && (
                        <tr>
                          <td colSpan={6} className="px-5 py-10 text-center text-gray-400 text-sm">No breakdown data available</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center py-12 text-gray-400 text-sm">No reply stats available</div>
          )}
        </motion.div>
      )}

      {activeTab === 'table' && isAdmin(user) && (
        <motion.div {...flip} className="space-y-5">
          {/* Filters */}
          <div className="relative z-30 bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="font-medium text-gray-700">Filters</p>
              {(countryFilter.length > 0 || stateFilter.length > 0 || domainFilter.length > 0 || industryFilter.length > 0 || uploaderFilter.length > 0 || mailSourceFilter.length > 0) && (
                <button
                  onClick={() => {
                    setCountryFilter([])
                    setStateFilter([])
                    setDomainFilter([])
                    setIndustryFilter([])
                    setUploaderFilter([])
                    setMailSourceFilter([])
                    setPage(1)
                  }}
                  className="text-xs font-medium text-red-500 hover:text-red-600 hover:underline transition-all cursor-pointer"
                >
                  Clear All
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {/* The search is now in the table header */}
              <MultiSelect
                label="Country"
                value={countryFilter}
                onChange={val => { setCountryFilter(val); setPage(1) }}
                options={countries.map(c => ({ label: c, value: c }))}
                placeholder="All Countries"
              />
              <MultiSelect
                label="State"
                value={stateFilter}
                onChange={val => { setStateFilter(val); setPage(1) }}
                options={states.map(s => ({ label: s, value: s }))}
                placeholder="All States"
              />
              <MultiSelect
                label="Domain"
                value={domainFilter}
                onChange={val => { setDomainFilter(val); setPage(1) }}
                options={domains.map(d => ({ label: d, value: d }))}
                placeholder="All Domains"
              />
              {/* <MultiSelect
                label="Industry"
                value={industryFilter}
                onChange={val => { setIndustryFilter(val); setPage(1) }}
                options={industries.map(i => ({ label: i, value: i }))}
                placeholder="All Industries"
              /> */}
              <MultiSelect
                label="Uploader"
                value={uploaderFilter}
                onChange={val => { setUploaderFilter(val); setPage(1) }}
                options={uploaders.map(u => ({ label: u.name, value: u.id }))}
                placeholder="All Uploaders"
              />
              <MultiSelect
                label="Mail Source"
                value={mailSourceFilter}
                onChange={val => { setMailSourceFilter(val); setPage(1) }}
                options={[
                  { label: 'Google Scholar', value: 'Google Scholar' },
                  { label: 'University', value: 'University' },
                  { label: 'Other', value: 'Other' },
                  ...mailSources
                    .filter(s => !['Google Scholar', 'University', 'Other'].includes(s))
                    .map(s => ({ label: s, value: s }))
                ]}
                placeholder="All Sources"
              />
            </div>
          </div>

          {/* Results Card */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            {/* Combined Header */}
            <div className="p-4 border-b border-gray-200 flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-white text-sm text-gray-500">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search records..."
                    className="pl-9 pr-4 py-2 w-full sm:w-64 bg-white border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                    value={search}
                    onChange={e => { setSearch(e.target.value); setPage(1) }}
                  />
                </div>
                {/* {selectedRows.length > 0 && (
                  <Button
                    className="bg-red-600 hover:bg-red-700 text-white border-transparent text-xs py-1.5 px-3 flex items-center h-[38px]"
                    onClick={() => setDeleteSelectedTarget(true)}
                    loading={deleteSelectedMut.isPending}
                  >
                    <Trash2 className="w-4 h-4 mr-1" /> Delete Selected ({selectedRows.length})
                  </Button>
                )} */}
                {user?.role === 'super_admin' && (
                  <>
                    <div className="flex items-center gap-2 relative" ref={datePickerRef}>
                      <div 
                        ref={datePickerTriggerRef}
                        className="w-[200px] bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-xs text-gray-700 cursor-pointer flex items-center justify-between hover:border-primary/50 transition-colors h-[38px]"
                        onClick={() => setShowDatePicker(!showDatePicker)}
                      >
                        <span>
                          {deleteStartDate 
                            ? `${format(new Date(deleteStartDate), 'MMM d, yyyy')} - ${deleteEndDate ? format(new Date(deleteEndDate), 'MMM d, yyyy') : '...'}` 
                            : 'Select Date to Delete'}
                        </span>
                        <Calendar className="w-3.5 h-3.5 text-gray-400" />
                      </div>
                      {showDatePicker && datePickerPosition && createPortal(
                        <div
                          ref={datePickerPopupRef}
                          className="fixed z-[110]"
                          style={datePickerPosition}
                        >
                          <DateRangePicker
                            startDate={deleteStartDate}
                            endDate={deleteEndDate}
                            onChange={(dates) => {
                              setDeleteStartDate(dates.start)
                              setDeleteEndDate(dates.end)
                              if (dates.start && dates.end) setShowDatePicker(false)
                            }}
                          />
                        </div>,
                        document.body
                      )}
                      {deleteStartDate && deleteEndDate && (
                        <Button 
                          className="bg-red-600 hover:bg-red-700 text-white border-transparent text-xs h-[38px] "
                          onClick={() => setDeleteDateRangeModal(true)}
                        >
                          <Trash2 className="w-3 h-3 " />
                        </Button>
                      )}
                    </div>
                    <Button variant="secondary" className="h-[38px]" onClick={() => setExportModal(true)}>
                      <Download className="w-4 h-4" />
                    </Button>
                  </>
                )}
                <div className="flex items-center h-[38px]">
                  Showing <span className="font-medium text-gray-900 mx-1">{total > 0 ? (page - 1) * pageSize + 1 : 0}-{Math.min(page * pageSize, total)}</span> of <span className="font-medium text-gray-900 mx-1">{total}</span> records
                </div>
              </div>

              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <span>Show:</span>
                  <select
                    value={pageSize}
                    onChange={e => { setPageSize(Number(e.target.value)); setPage(1) }}
                    className="border border-gray-200 rounded-md py-1 px-2 bg-white focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                    <option value={500}>500</option>
                  </select>
                </div>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setPage(Math.max(1, page - 1))}
                    disabled={page === 1}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <span>Page {page} of {totalPages}</span>
                  <button
                    onClick={() => setPage(Math.min(totalPages, page + 1))}
                    disabled={page === totalPages}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Table */}
            <Table columns={columns} data={records} loading={isLoading || isFetching} emptyMsg="No emails found" wrapperClassName="overflow-auto bg-white max-h-[calc(100vh-320px)] relative" />
          </div>
        </motion.div>
      )}

      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Confirm Delete">
        <div className="space-y-4">
          <p className="text-gray-700">Are you sure you want to delete the email <strong>{deleteTarget?.email}</strong>?</p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white border-transparent" onClick={() => { deleteMut.mutate(deleteTarget?.id); setDeleteTarget(null); }} loading={deleteMut.isPending}>Delete</Button>
          </div>
        </div>
      </Modal>

      <Modal
        open={!!editTarget}
        onClose={() => {
          if (!updateEmailMut.isPending) {
            setEditTarget(null)
            setEditForm(null)
          }
        }}
        title="Edit Email Details"
        size="lg"
      >
        {editForm && (
          <form
            className="space-y-5"
            onSubmit={e => {
              e.preventDefault()
              updateEmailMut.mutate({
                id: editTarget.id || editTarget._id,
                data: {
                  ...editForm,
                  domain_group: editForm.domain_group
                    .split(',')
                    .map(value => value.trim())
                    .filter(Boolean),
                }
              })
            }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                ['email', 'Email'],
                ['fullName', 'Full Name'],
                ['university', 'University'],
                ['website', 'Website'],
                ['country', 'Country'],
                ['state', 'State'],
                ['city', 'City'],
                ['domain', 'Domain'],
                ['domain_group', 'Domain Group'],
                ['industry', 'Industry'],
                ['designation', 'Designation'],
                ['phone', 'Phone'],
                ['linkedin', 'LinkedIn'],
              ].map(([key, label]) => (
                <Input
                  key={key}
                  label={label}
                  value={editForm[key]}
                  disabled={label==='Email'}
                  onChange={e => setEditForm(prev => ({ ...prev, [key]: e.target.value }))}
                  maxLength={key==='phone'?10:undefined}
                />
              ))}
            </div>
            <div className="flex justify-end gap-2 border-t border-gray-100 pt-4">
              <Button
                type="button"
                variant="secondary"
                disabled={updateEmailMut.isPending}
                onClick={() => {
                  setEditTarget(null)
                  setEditForm(null)
                }}
              >
                Cancel
              </Button>
              <Button type="submit" loading={updateEmailMut.isPending}>
                Save Changes
              </Button>
            </div>
          </form>
        )}
      </Modal>

      <Modal open={deleteSelectedTarget} onClose={() => setDeleteSelectedTarget(false)} title="Confirm Delete">
        <div className="space-y-4">
          <p className="text-gray-700">Are you sure you want to delete {selectedRows.length} selected emails?</p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setDeleteSelectedTarget(false)}>Cancel</Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white border-transparent" onClick={() => { deleteSelectedMut.mutate(selectedRows); setDeleteSelectedTarget(false); }} loading={deleteSelectedMut.isPending}>Delete</Button>
          </div>
        </div>
      </Modal>

      <Modal open={deleteDateRangeModal} onClose={() => setDeleteDateRangeModal(false)} title="Confirm Delete By Date">
        <div className="space-y-4">
          <p className="text-gray-700">Are you sure you want to delete all emails uploaded between <strong>{deleteStartDate}</strong> and <strong>{deleteEndDate}</strong>?</p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setDeleteDateRangeModal(false)}>Cancel</Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white border-transparent" onClick={() => deleteByDateRangeMut.mutate()} loading={deleteByDateRangeMut.isPending}>Delete</Button>
          </div>
        </div>
      </Modal>
      {/* Export Modal */}
      <Modal open={exportModal} onClose={() => !exportMut.isPending && setExportModal(false)} title="Export Emails">
        <div className="space-y-4">
          <p className="text-gray-700 text-sm">Select the format you want to export the data in. Current filters will be applied to the exported file.</p>
          <Select label="Export Format" value={exportFormat} onChange={(e) => setExportFormat(e.target.value)}>
            <option value="xlsx">Excel (.xlsx)</option>
            <option value="csv">CSV (.csv)</option>
          </Select>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setExportModal(false)} disabled={exportMut.isPending}>Cancel</Button>
            <Button onClick={() => exportMut.mutate(exportFormat)} loading={exportMut.isPending}>
              Download
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}