import { useMemo, useState } from 'react'
import {
  Activity, AlertCircle, ArrowDownToLine, Check, ChevronDown, ChevronRight,
  Circle, Code2, Command, FileCode2, FileJson, FileText, Folder, GitBranch,
  Play, Plus, RefreshCw, Search, ShieldCheck, Terminal, X
} from 'lucide-react'

const initialFiles = [
  { name: 'src', type: 'folder', children: [
    { name: 'App.jsx', type: 'code', language: 'jsx', content: `import React from 'react'\nimport { Routes, Route } from 'react-router-dom'\n\nexport default function App() {\n  return (\n    <Routes>\n      <Route path=\"/\" element={<Dashboard />} />\n    </Routes>\n  )\n}` },
    { name: 'main.jsx', type: 'code', language: 'jsx', content: `import React from 'react'\nimport ReactDOM from 'react-dom/client'\nimport App from './App'\nimport './index.css'\n\nReactDOM.createRoot(document.getElementById('root')).render(\n  <React.StrictMode><App /></React.StrictMode>\n)` },
    { name: 'index.css', type: 'code', language: 'css', content: `@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\n:root {\n  font-family: Inter, sans-serif;\n  color-scheme: light;\n}` },
  ]},
  { name: 'backend', type: 'folder', children: [
    { name: 'main.py', type: 'code', language: 'python', content: `from fastapi import FastAPI\n\napp = FastAPI(title=\"Project API\")\n\n@app.get(\"/health\")\ndef health_check():\n    return {\"status\": \"ok\"}` },
    { name: 'requirements.txt', type: 'text', language: 'text', content: 'fastapi\nuvicorn[standard]\npydantic' },
  ]},
  { name: 'package.json', type: 'json', language: 'json', content: `{\n  \"name\": \"project-workspace\",\n  \"private\": true,\n  \"scripts\": {\n    \"dev\": \"vite\",\n    \"build\": \"vite build\",\n    \"test\": \"vitest\"\n  },\n  \"dependencies\": {\n    \"react\": \"^18.3.1\",\n    \"react-dom\": \"^18.3.1\"\n  }\n}` },
  { name: 'README.md', type: 'text', language: 'markdown', content: '# Project Workspace\n\nDeveloper workspace preview.\n\n- React frontend\n- FastAPI backend\n- Restricted command runner (planned)' },
]

const commandSamples = [
  { label: 'Install dependencies', command: 'npm install', icon: ArrowDownToLine },
  { label: 'Run development server', command: 'npm run dev', icon: Play },
  { label: 'Build project', command: 'npm run build', icon: Check },
  { label: 'Run tests', command: 'npm test', icon: Activity },
]

function flattenFiles(items, parent = '') {
  return items.flatMap(item => {
    const path = parent ? `${parent}/${item.name}` : item.name
    return item.type === 'folder' ? flattenFiles(item.children || [], path) : [{ ...item, path }]
  })
}

export default function DeveloperDashboard() {
  const allFiles = useMemo(() => flattenFiles(initialFiles), [])
  const [activeFile, setActiveFile] = useState('src/App.jsx')
  const [contents, setContents] = useState(() => Object.fromEntries(allFiles.map(f => [f.path, f.content || '']))
  )
  const [command, setCommand] = useState('npm run build')
  const [output, setOutput] = useState([
    { type: 'system', text: 'Developer preview workspace initialized.' },
    { type: 'system', text: 'Mock mode is active. Commands are simulated and no files are saved to disk.' },
  ])
  const [activePanel, setActivePanel] = useState('terminal')
  const [search, setSearch] = useState('')
  const [running, setRunning] = useState(false)
  const [saved, setSaved] = useState(false)
  const [expanded, setExpanded] = useState({ src: true, backend: true })

  const selected = allFiles.find(file => file.path === activeFile)
  const visibleFiles = allFiles.filter(file => file.path.toLowerCase().includes(search.toLowerCase()))

  const runMockCommand = (value = command) => {
    const trimmed = value.trim()
    if (!trimmed) return
    setCommand(trimmed)
    setRunning(true)
    setActivePanel('terminal')
    setOutput(prev => [...prev, { type: 'command', text: `$ ${trimmed}` }])
    window.setTimeout(() => {
      let lines
      if (trimmed === 'npm run build') {
        lines = [
          { type: 'success', text: '✓ vite build (simulated)' },
          { type: 'system', text: 'dist/ generated successfully — preview only' },
          { type: 'success', text: 'Done. No real command was executed.' },
        ]
      } else if (trimmed === 'npm test' || trimmed === 'npm run test') {
        lines = [
          { type: 'success', text: '✓ Test suite passed (simulated)' },
          { type: 'system', text: '0 failed · Demo output only' },
        ]
      } else if (trimmed === 'npm install') {
        lines = [
          { type: 'system', text: 'Dependency installation preview' },
          { type: 'success', text: '✓ package.json detected (simulated)' },
          { type: 'system', text: 'Connect the FastAPI command runner to install packages for real.' },
        ]
      } else if (trimmed === 'npm run dev') {
        lines = [
          { type: 'success', text: '✓ Vite development server (simulated)' },
          { type: 'system', text: 'Local: http://localhost:5173/ (display only; no server started)' },
        ]
      } else {
        lines = [
          { type: 'warning', text: 'Preview mode does not execute arbitrary commands.' },
          { type: 'system', text: 'Only the sample actions are simulated. Real execution will be added after backend review.' },
        ]
      }
      setOutput(prev => [...prev, ...lines])
      setRunning(false)
    }, 550)
  }

  const savePreview = () => {
    setSaved(true)
    setOutput(prev => [...prev, { type: 'system', text: `Preview edit for ${activeFile} held in browser state only; not saved to disk.` }])
    window.setTimeout(() => setSaved(false), 2200)
  }

  const fileIcon = (file) => {
    if (file.language === 'json') return <FileJson className="h-4 w-4 text-amber-500" />
    if (file.language === 'python') return <FileCode2 className="h-4 w-4 text-sky-500" />
    if (file.language === 'jsx' || file.language === 'css') return <FileCode2 className="h-4 w-4 text-indigo-500" />
    return <FileText className="h-4 w-4 text-slate-400" />
  }

  return (
    <div className="mx-auto flex h-full min-h-[680px] max-w-[1600px] flex-col gap-5">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-indigo-600">
            <Code2 className="h-4 w-4" /> Developer tools
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Developer workspace</h1>
          <p className="mt-1 text-sm text-slate-500">Inspect files, review changes, and manage project tasks from one place.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-800">
            <span className="h-2 w-2 rounded-full bg-amber-500" /> Mock preview
          </span>
          <button onClick={() => { setOutput([{ type: 'system', text: 'Preview console cleared.' }]); setActivePanel('terminal') }} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200">
            <RefreshCw className="h-4 w-4" /> Reset console
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[
          { label: 'Workspace', value: 'Connected preview', note: 'Local UI state', icon: Folder, color: 'text-indigo-600 bg-indigo-50' },
          { label: 'Source files', value: `${allFiles.length} files`, note: 'Sample file tree', icon: FileCode2, color: 'text-sky-600 bg-sky-50' },
          { label: 'Command runner', value: 'Simulation only', note: 'Backend not connected', icon: Terminal, color: 'text-amber-600 bg-amber-50' },
          { label: 'Access mode', value: 'Developer', note: 'Mock account', icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-50' },
        ].map(({ label, value, note, icon: Icon, color }) => (
          <div key={label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <div className="flex items-start justify-between gap-2">
              <div><p className="text-xs font-medium text-slate-500">{label}</p><p className="mt-1 text-sm font-bold text-slate-900 dark:text-slate-100">{value}</p></div>
              <span className={`rounded-lg p-2 ${color}`}><Icon className="h-4 w-4" /></span>
            </div>
            <p className="mt-3 text-xs text-slate-400">{note}</p>
          </div>
        ))}
      </div>

      <div className="grid min-h-[500px] flex-1 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-900 xl:grid-cols-[250px_minmax(0,1fr)]">
        <aside className="flex min-h-[260px] flex-col border-b border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-950/50 xl:border-b-0 xl:border-r">
          <div className="flex h-12 items-center justify-between border-b border-slate-200 px-4 dark:border-slate-700">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Explorer</span>
            <button title="Preview only" className="rounded p-1 text-slate-400"><Plus className="h-4 w-4" /></button>
          </div>
          <div className="border-b border-slate-200 p-3 dark:border-slate-700">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search files..." className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-8 pr-3 text-xs outline-none focus:border-indigo-400 dark:border-slate-700 dark:bg-slate-900" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            <div className="mb-2 flex items-center gap-2 px-2 py-1 text-xs font-semibold text-slate-500"><Folder className="h-4 w-4 text-amber-500" /> project-workspace</div>
            {visibleFiles.map(file => (
              <button key={file.path} onClick={() => { setActiveFile(file.path); setSaved(false) }} className={`flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-xs transition ${activeFile === file.path ? 'bg-indigo-100 font-semibold text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'}`}>
                <span className="w-3 text-slate-300">↳</span>{fileIcon(file)}<span className="truncate">{file.path}</span>
              </button>
            ))}
            {visibleFiles.length === 0 && <p className="px-3 py-5 text-xs text-slate-400">No matching files</p>}
          </div>
          <div className="border-t border-slate-200 p-3 dark:border-slate-700">
            <div className="flex items-center gap-2 text-xs text-slate-500"><GitBranch className="h-3.5 w-3.5" /> preview-branch <span className="ml-auto text-emerald-600">● clean</span></div>
          </div>
        </aside>

        <section className="flex min-w-0 flex-col">
          <div className="flex min-h-12 flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 dark:border-slate-700">
            <div className="flex items-center gap-2 text-xs text-slate-500"><FileCode2 className="h-4 w-4 text-indigo-500" /> {activeFile} <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] uppercase dark:bg-slate-800">{selected?.language || 'text'}</span></div>
            <div className="flex items-center gap-2">
              {saved && <span className="text-xs text-emerald-600">Preview updated</span>}
              <button onClick={savePreview} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500">{saved ? 'Updated' : 'Save preview'}</button>
            </div>
          </div>
          <div className="min-h-[270px] flex-1 bg-white dark:bg-slate-900">
            <div className="flex h-full min-h-[270px]">
              <div className="hidden select-none flex-col items-end gap-0.5 border-r border-slate-100 bg-slate-50 px-3 py-4 font-mono text-xs leading-6 text-slate-300 sm:flex dark:border-slate-800 dark:bg-slate-950/40">
                {Array.from({ length: Math.max(1, (contents[activeFile] || '').split('\n').length) }, (_, i) => <span key={i}>{i + 1}</span>)}
              </div>
              <textarea spellCheck={false} value={contents[activeFile] || ''} onChange={e => { setContents(prev => ({ ...prev, [activeFile]: e.target.value })); setSaved(false) }} className="min-h-[270px] w-full resize-y bg-transparent p-4 font-mono text-xs leading-6 text-slate-700 outline-none dark:text-slate-200" aria-label="Mock code editor" />
            </div>
          </div>
          <div className="border-t border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-1 border-b border-slate-200 px-3 dark:border-slate-700">
              <button onClick={() => setActivePanel('terminal')} className={`flex items-center gap-2 border-b-2 px-3 py-3 text-xs font-semibold ${activePanel === 'terminal' ? 'border-indigo-600 text-indigo-700 dark:text-indigo-300' : 'border-transparent text-slate-500'}`}><Terminal className="h-3.5 w-3.5" /> Terminal preview</button>
              <button onClick={() => setActivePanel('problems')} className={`flex items-center gap-2 border-b-2 px-3 py-3 text-xs font-semibold ${activePanel === 'problems' ? 'border-indigo-600 text-indigo-700 dark:text-indigo-300' : 'border-transparent text-slate-500'}`}><AlertCircle className="h-3.5 w-3.5" /> Problems <span className="rounded-full bg-slate-100 px-1.5 dark:bg-slate-800">0</span></button>
            </div>
            {activePanel === 'terminal' ? (
              <div className="p-4">
                <div className="mb-3 flex flex-wrap gap-2">
                  {commandSamples.map(item => <button key={item.command} onClick={() => setCommand(item.command)} className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-2.5 py-1.5 text-[11px] font-medium text-slate-600 hover:border-indigo-300 hover:text-indigo-700 dark:border-slate-700 dark:text-slate-300"><item.icon className="h-3 w-3" /> {item.label}</button>)}
                </div>
                <form onSubmit={e => { e.preventDefault(); runMockCommand() }} className="flex gap-2">
                  <div className="flex min-w-0 flex-1 items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 dark:border-slate-700 dark:bg-slate-950"><Command className="h-4 w-4 shrink-0 text-slate-400" /><input value={command} onChange={e => setCommand(e.target.value)} className="w-full bg-transparent py-2.5 font-mono text-xs outline-none" aria-label="Command preview" /><ChevronDown className="h-4 w-4 text-slate-400" /></div>
                  <button disabled={running} className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50 dark:bg-indigo-600"><Play className="h-3.5 w-3.5" /> {running ? 'Running…' : 'Run preview'}</button>
                </form>
                <div className="mt-3 max-h-44 overflow-y-auto rounded-lg bg-slate-950 p-3 font-mono text-[11px] leading-5">
                  {output.map((line, index) => <div key={`${index}-${line.text}`} className={line.type === 'success' ? 'text-emerald-400' : line.type === 'warning' ? 'text-amber-300' : line.type === 'command' ? 'text-sky-300' : 'text-slate-300'}>{line.text}</div>)}
                  {running && <div className="animate-pulse text-slate-400">Simulating command output…</div>}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-6 text-sm text-slate-500"><Check className="h-5 w-5 text-emerald-500" /> No preview diagnostics to display.</div>
            )}
          </div>
        </section>
      </div>
      <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
        <p><strong>Design preview only:</strong> sample files and terminal output are mock data. Editor changes stay in browser memory. No backend requests, real commands, or disk writes occur in this preview.</p>
      </div>
    </div>
  )
}
